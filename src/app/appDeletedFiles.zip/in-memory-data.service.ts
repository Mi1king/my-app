import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const positions =
      [{ Latitude: 31.381982194, Longitude: 120.9935871028, Id: 9 },
      { Latitude: 31.326507939, Longitude: 120.6091348566, Id: 5 },
      { Latitude: 31.1817709761, Longitude: 120.7287000396, Id: 6 },
      { Latitude: 31.0213871824, Longitude: 120.696655677, Id: 2 },
      { Latitude: 31.3232737123, Longitude: 120.6190530366, Id: 9 },
      { Latitude: 31.3003965185, Longitude: 120.5456678955, Id: 5 },
      { Latitude: 31.4530382899, Longitude: 120.5328194983, Id: 9 },
      { Latitude: 31.3815296734, Longitude: 120.948156963, Id: 5 },
      { Latitude: 31.0511634603, Longitude: 120.8102880401, Id: 10 },
      { Latitude: 31.3221450476, Longitude: 120.6657241694, Id: 1 },
      { Latitude: 31.4654342181, Longitude: 120.6140625126, Id: 4 },
      { Latitude: 31.2294470932, Longitude: 120.9183783017, Id: 2 },
      { Latitude: 31.2482722012, Longitude: 120.9924824597, Id: 2 },
      { Latitude: 31.2700796086, Longitude: 120.5115746082, Id: 2 },
      { Latitude: 31.2090876275, Longitude: 120.8733457124, Id: 7 },
      { Latitude: 31.1228129969, Longitude: 120.6281003464, Id: 2 },
      { Latitude: 31.2408480939, Longitude: 120.5460577916, Id: 3 },
      { Latitude: 31.0382284966, Longitude: 120.6592228966, Id: 9 },
      { Latitude: 31.4122993152, Longitude: 120.8516295153, Id: 2 },
      { Latitude: 31.3658677721, Longitude: 120.7463318762, Id: 10 },
      { Latitude: 31.46033975, Longitude: 120.983005078, Id: 9 },
      { Latitude: 31.134792121, Longitude: 120.7083288326, Id: 8 },
      { Latitude: 31.3439263155, Longitude: 120.8856409564, Id: 7 },
      { Latitude: 31.1066110677, Longitude: 120.622165548, Id: 2 },
      { Latitude: 31.318125869, Longitude: 120.5969051081, Id: 7 },
      { Latitude: 31.3175911582, Longitude: 120.7268437416, Id: 10 },
      { Latitude: 31.3724021603, Longitude: 120.7701254308, Id: 6 },
      { Latitude: 31.2264083984, Longitude: 120.838339993, Id: 8 },
      { Latitude: 31.1250438311, Longitude: 120.8632011942, Id: 0 },
      { Latitude: 31.263339168, Longitude: 120.6093018053, Id: 1 },
      { Latitude: 31.0932998987, Longitude: 120.7803942645, Id: 5 },
      { Latitude: 31.3541281794, Longitude: 120.8497870747, Id: 8 },
      { Latitude: 31.1991710656, Longitude: 120.7768856812, Id: 2 },
      { Latitude: 31.3263795845, Longitude: 120.5931438856, Id: 8 },
      { Latitude: 31.4188612973, Longitude: 120.5144095317, Id: 7 },
      { Latitude: 31.0684128465, Longitude: 120.5915522496, Id: 5 },
      { Latitude: 31.3288983297, Longitude: 120.8381407717, Id: 3 },
      { Latitude: 31.0193894513, Longitude: 120.6159879006, Id: 3 },
      { Latitude: 31.2281108132, Longitude: 120.6766262179, Id: 10 },
      { Latitude: 31.1235059344, Longitude: 120.6347667377, Id: 4 },
      { Latitude: 31.4290550781, Longitude: 120.728443726, Id: 7 },
      { Latitude: 31.0163394525, Longitude: 120.9138293184, Id: 5 },
      { Latitude: 31.1728601953, Longitude: 120.5400423128, Id: 7 },
      { Latitude: 31.1463113726, Longitude: 120.8028283584, Id: 2 },
      { Latitude: 31.0454330661, Longitude: 120.8310021505, Id: 5 },
      { Latitude: 31.1700272549, Longitude: 120.8863078442, Id: 8 },
      { Latitude: 31.112711422, Longitude: 120.6744917476, Id: 6 },
      { Latitude: 31.3011649917, Longitude: 120.5462453048, Id: 7 },
      { Latitude: 31.3365438455, Longitude: 120.9221833209, Id: 10 },
      { Latitude: 31.4102196418, Longitude: 120.5046168855, Id: 4 },
      { Latitude: 31.0620248804, Longitude: 120.5857318227, Id: 4 },
      { Latitude: 31.253704516, Longitude: 120.9425359672, Id: 7 },
      { Latitude: 31.3164059849, Longitude: 120.8751301459, Id: 10 },
      { Latitude: 31.3709284711, Longitude: 120.8621625962, Id: 3 },
      { Latitude: 31.1463691233, Longitude: 120.6322526661, Id: 2 },
      { Latitude: 31.2787504442, Longitude: 120.9606598151, Id: 8 },
      { Latitude: 31.1045268041, Longitude: 120.9305401626, Id: 4 },
      { Latitude: 31.0882396669, Longitude: 120.7414723642, Id: 4 },
      { Latitude: 31.0373689756, Longitude: 120.6894783809, Id: 4 },
      { Latitude: 31.246778372, Longitude: 120.6610533732, Id: 7 },
      { Latitude: 31.3882232765, Longitude: 120.9385476111, Id: 10 },
      { Latitude: 31.1572778803, Longitude: 120.9943091348, Id: 4 },
      { Latitude: 31.0152068276, Longitude: 120.8043389899, Id: 1 },
      { Latitude: 31.2460490787, Longitude: 120.5030311071, Id: 5 },
      { Latitude: 31.1229758232, Longitude: 120.8117309377, Id: 10 },
      { Latitude: 31.4961927316, Longitude: 120.6492517979, Id: 3 },
      { Latitude: 31.2436351204, Longitude: 120.991612134, Id: 8 },
      { Latitude: 31.0753642064, Longitude: 120.8493474182, Id: 8 },
      { Latitude: 31.2896288493, Longitude: 120.7805807208, Id: 3 },
      { Latitude: 31.2836200327, Longitude: 120.5055332719, Id: 8 },
      { Latitude: 31.0637019517, Longitude: 120.8809843211, Id: 2 },
      { Latitude: 31.0035973056, Longitude: 120.6318364789, Id: 9 },
      { Latitude: 31.489851411, Longitude: 120.8870261777, Id: 2 },
      { Latitude: 31.1860941925, Longitude: 120.5301225008, Id: 5 },
      { Latitude: 31.1650716292, Longitude: 120.8687970182, Id: 9 },
      { Latitude: 31.3358633614, Longitude: 120.8643430831, Id: 9 },
      { Latitude: 31.4642568375, Longitude: 120.8404772228, Id: 6 },
      { Latitude: 31.4364258103, Longitude: 120.6317460668, Id: 3 },
      { Latitude: 31.3964768428, Longitude: 120.883848742, Id: 9 },
      { Latitude: 31.1808656489, Longitude: 120.5235623328, Id: 10 },
      { Latitude: 31.420729714, Longitude: 120.8443574867, Id: 4 },
      { Latitude: 31.3009459985, Longitude: 120.6483885045, Id: 3 },
      { Latitude: 31.2510053332, Longitude: 120.5254283983, Id: 8 },
      { Latitude: 31.3901854296, Longitude: 120.5119376502, Id: 10 },
      { Latitude: 31.4095691592, Longitude: 120.7429588185, Id: 0 },
      { Latitude: 31.0689368735, Longitude: 120.5961554225, Id: 8 },
      { Latitude: 31.0709016594, Longitude: 120.7490800873, Id: 4 },
      { Latitude: 31.0045430752, Longitude: 120.8893422995, Id: 1 },
      { Latitude: 31.4559841867, Longitude: 120.6478053551, Id: 2 },
      { Latitude: 31.2691689916, Longitude: 120.8907052135, Id: 5 },
      { Latitude: 31.4242983496, Longitude: 120.8792371386, Id: 2 },
      { Latitude: 31.0067187795, Longitude: 120.7914286938, Id: 2 },
      { Latitude: 31.358708487, Longitude: 120.9203678583, Id: 5 },
      { Latitude: 31.0224214984, Longitude: 120.8266371716, Id: 9 },
      { Latitude: 31.2110906021, Longitude: 120.6841440467, Id: 3 },
      { Latitude: 31.1208544905, Longitude: 120.5658999937, Id: 8 },
      { Latitude: 31.4964896846, Longitude: 120.7514232857, Id: 9 },
      { Latitude: 31.4621588228, Longitude: 120.6777558927, Id: 1 },
      { Latitude: 31.4313175383, Longitude: 120.7495779629, Id: 5 },
      { Latitude: 31.1470370303, Longitude: 120.8890526098, Id: 8 }]
      ;
    // const massMarker: MassMarker[] = [];
    // positions.forEach(element => {
    //   massMarker.push({
    //     lnglat: [element.Longitude, element.Latitude],
    //     name: element.Id as unknown as string,
    //     id: 1,
    //     style: 0
    //   })
    // });

    // return { positions, massMarker };
    return { positions };
  }

  // // Overrides the genId method to ensure that a hero always has an id.
  // // If the heroes array is empty,
  // // the method below returns the initial number (11).
  // // if the heroes array is not empty, the method below returns the highest
  // // hero id + 1.
  // genId(positions: Position[]): number {
  //   return heroes.length > 0 ? Math.max(...heroes.map(hero => hero.id)) + 1 : 11;
  // }

}