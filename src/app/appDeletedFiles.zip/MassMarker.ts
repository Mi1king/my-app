export interface MassMarker {
    lnglat: Array<string | number>,
    name: string,
    id: number,
}