import { Component, OnInit } from '@angular/core';
import { MyPositionsService } from '../my-positions.service';
import { Position } from '../Position';
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit {


  city = '上海';
  mapstyle = 'amap://styles/359cd302f9c595376f3cff175297f6c6';
  hidden = false;
  language: AMap.Lang = 'en';

  positions: Position[] = [];

  constructor(
    private positionsService: MyPositionsService
  ) { }

  ngOnInit() {
    this.getPositions();
    // this.showPositions();
  }

  // showPositions() {
  //   for (var i = 0; i < capitals.length; i += 1) {
  //     var center = capitals[i].center;
  //     var circleMarker = new AMap.CircleMarker({
  //       center: center,
  //       radius: 11 + Math.random() * 10,//3D视图下，CircleMarker半径不要超过64px
  //       strokeColor: 'white',
  //       strokeWeight: 2,
  //       strokeOpacity: 0.5,
  //       fillColor: 'rgba(0,0,255,1)',
  //       fillOpacity: 0.5,
  //       zIndex: 10,
  //       bubble: true,
  //       cursor: 'pointer',
  //       clickable: true
  //     })
  //     circleMarker.setMap(map)
  //   }

  //   var mass = new AMap.MassMarks(citys, {
  //     opacity: 0.8,
  //     zIndex: 111,
  //     cursor: 'pointer',
  //     style: style
  //   });
  //   var marker = new AMap.Marker({ content: ' ', map: map });

  //   mass.on('mouseover', function (e) {

  //     marker.setPosition(e.data.lnglat);
  //     marker.setLabel({ content: e.data.name })
  //   });

  //   mass.setMap(map);

  // }



  getPositions(): void {
    this.positionsService
      .getPositions()
      .subscribe((positions) => (this.positions = positions));
  }

}
