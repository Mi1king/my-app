export interface Position{
    Id: number
    Latitude: number;
    Longitude: number;
}