import { Component, OnInit } from '@angular/core';

import { NzTableFilterFn, NzTableFilterList, NzTableSortFn, NzTableSortOrder } from 'ng-zorro-antd/table';
import { MyPositionsService } from '../my-positions.service';
import { Position } from '../Position';


interface ColumnItem {
  name: string;
  sortOrder: NzTableSortOrder | null;
  sortFn: NzTableSortFn<Position> | null;
  listOfFilter: NzTableFilterList;
  filterFn: NzTableFilterFn<Position> | null;
  filterMultiple: boolean;
  sortDirections: NzTableSortOrder[];
}

@Component({
  selector: 'app-info-table',
  templateUrl: './info-table.component.html'
})
export class InfoTableComponent implements OnInit {

  
  constructor(
    private positionsService: MyPositionsService
  ) { }

  ngOnInit(): void {
    this.getPositions();
  }

  positions: Position[] = [];
  tableSize = "small";
  listOfColumns: ColumnItem[] = [
    {
      name: 'Id',
      sortOrder: null,
      sortFn: (a: Position, b: Position) => a.Id - b.Id,
      sortDirections: ['ascend', 'descend', null],
      filterMultiple: true,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'Logitude',
      sortOrder: 'descend',
      sortFn: null,
      sortDirections: ['descend', null],
      listOfFilter: [],
      filterFn: null,
      filterMultiple: true
    },
    {
      name: 'Latitude',
      sortOrder: null,
      sortDirections: ['ascend', 'descend', null],
      sortFn: null,
      filterMultiple: false,
      listOfFilter: [],
      filterFn: null
    },
    {
      name: 'Speed',
      sortOrder: null,
      sortDirections: ['ascend', 'descend', null],
      sortFn: null,
      filterMultiple: false,
      listOfFilter: [],
      filterFn: null
    }
  ];


  getPositions(): void {
    this.positionsService
      .getPositions()
      .subscribe((positions) => (this.positions = positions));
  }
}

